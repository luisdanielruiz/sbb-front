function loadPageIndex(){
	$(".page").addClass("cached");

	if($(".index").length>0){			
		$(".index").removeClass("cached");
	
    }
}