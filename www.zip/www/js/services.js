var urlServer="35.239.34.187";
//var urlServer="localhost:8085";

var appServices = {
 SBBListarRetos:"http://"+urlServer+"/SBB/SBBListarChallenges",
 SBBLogin:"http://"+urlServer+"/SBB/SBBLoginManual",
 TySRegister:"http://"+urlServer+"/SBB/SBBRegistroManual",
 TySMyAccount:"http://"+urlServer+"/SBB/SBBMyAccount",
 TySImg:"http://"+urlServer+"/contextoPlenus/",
 TySContacto:"http://"+urlServer+"/SBB/SBBContacto",
 TySRecovery:"http://"+urlServer+"/SBB/SBBRecuperarPassword",
 TySConfirmarMail:"http://"+urlServer+"/SBB/SBBConfirmarMail",
 //TySVersionLocal:"http://touchandshopapp.com:8080/contextoPlenus/version.txt"
};